const onlineFps = document.querySelector('#onlineFps')
const onlineRpg = document.querySelector('#onlineRpg')
const onlineAos = document.querySelector('#onlineAos')
const onlineAction = document.querySelector('#onlineAction')
const onlineSports = document.querySelector('#onlineSports')
const steamFps = document.querySelector('#steamFps')
const steamRpg = document.querySelector('#steamRpg')
const steamAos = document.querySelector('#steamAos')
const steamSports = document.querySelector('#steamSports')
const steamAction = document.querySelector('#steamAction')

function orpg(){
    onlineFps.style.display= "none";
    onlineRpg.style.display= "block";
    onlineAos.style.display= "none";
    onlineAction.style.display= "none";
    onlineSports.style.display= "none";
    steamFps.style.display= "none";
    steamRpg.style.display= "none";
    steamAos.style.display= "none";
    steamSports.style.display= "none";
    steamAction.style.display= "none";
}


function ofps(){
    onlineFps.style.display= "block";
    onlineRpg.style.display= "none";
    onlineAos.style.display= "none";
    onlineAction.style.display= "none";
    onlineSports.style.display= "none";
    steamFps.style.display= "none";
    steamRpg.style.display= "none";
    steamAos.style.display= "none";
    steamSports.style.display= "none";
    steamAction.style.display= "none";
}
                          



function oaos(){
    onlineFps.style.display= "none";
    onlineRpg.style.display= "none";
    onlineAos.style.display= "block";
    onlineAction.style.display= "none";
    onlineSports.style.display= "none";
    steamFps.style.display= "none";
    steamRpg.style.display= "none";
    steamAos.style.display= "none";
    steamSports.style.display= "none";
    steamAction.style.display= "none";
}
                            



function osports(){
    onlineFps.style.display= "none";
    onlineRpg.style.display= "none";
    onlineAos.style.display= "none";
    onlineAction.style.display= "none";
    onlineSports.style.display= "block";
    steamFps.style.display= "none";
    steamRpg.style.display= "none";
    steamAos.style.display= "none";
    steamSports.style.display= "none";
    steamAction.style.display= "none";
}
                            


function oaction(){
    onlineFps.style.display= "none";
    onlineRpg.style.display= "none";
    onlineAos.style.display= "none";
    onlineAction.style.display= "block";
    onlineSports.style.display= "none";
    steamFps.style.display= "none";
    steamRpg.style.display= "none";
    steamAos.style.display= "none";
    steamSports.style.display= "none";
    steamAction.style.display= "none";
}

// 스팀
function sRpg(){
    onlineFps.style.display= "none";
    onlineRpg.style.display= "none";
    onlineAos.style.display= "none";
    onlineAction.style.display= "none";
    onlineSports.style.display= "none";
    steamFps.style.display= "none";
    steamRpg.style.display= "block";
    steamAos.style.display= "none";
    steamSports.style.display= "none";
    steamAction.style.display= "none";
}
function sfps(){
    onlineFps.style.display= "none";
    onlineRpg.style.display= "none";
    onlineAos.style.display= "none";
    onlineAction.style.display= "none";
    onlineSports.style.display= "none";
    steamFps.style.display= "block";
    steamRpg.style.display= "none";
    steamAos.style.display= "none";
    steamSports.style.display= "none";
    steamAction.style.display= "none";
}
function saos(){
    onlineFps.style.display= "none";
    onlineRpg.style.display= "none";
    onlineAos.style.display= "none";
    onlineAction.style.display= "none";
    onlineSports.style.display= "none";
    steamFps.style.display= "none";
    steamRpg.style.display= "none";
    steamAos.style.display= "block";
    steamSports.style.display= "none";
    steamAction.style.display= "none";
}
function ssports(){
    onlineFps.style.display= "none";
    onlineRpg.style.display= "none";
    onlineAos.style.display= "none";
    onlineAction.style.display= "none";
    onlineSports.style.display= "none";
    steamFps.style.display= "none";
    steamRpg.style.display= "none";
    steamAos.style.display= "none";
    steamSports.style.display= "block";
    steamAction.style.display= "none";
}
function saction(){
    onlineFps.style.display= "none";
    onlineRpg.style.display= "none";
    onlineAos.style.display= "none";
    onlineAction.style.display= "none";
    onlineSports.style.display= "none";
    steamFps.style.display= "none";
    steamRpg.style.display= "none";
    steamAos.style.display= "none";
    steamSports.style.display= "none";
    steamAction.style.display= "block";
}